package PizzaCalories;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] pizzaInput = readLine(scanner);
        try {
            Pizza pizza = createPizza(pizzaInput);

            String[] doughInput = readLine(scanner);

            Dough dough = createDough(doughInput);
            pizza.setDough(dough);

            String input;
            while (!(input = scanner.nextLine()).equals("END")) {
                String[] toppingInput = input.split("\\s+");
                String toppingName = toppingInput[1];
                double weight = Double.parseDouble(toppingInput[2]);
                Topping topping = new Topping(toppingName, weight);
                pizza.addTopping(topping);
                System.out.printf("%s - %.2f%n", pizza.getName(), pizza.getOverAllCalories());
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        

    }


    private static Dough createDough(String[] doughInput) {
        String flourType = doughInput[1];
        String bakingTechnique = doughInput[2];
        double weight = Double.parseDouble(doughInput[3]);
        return new Dough(flourType, bakingTechnique, weight);
    }

    private static String[] readLine(Scanner scanner) {
        return scanner.nextLine().split("\\s+");
    }

    private static Pizza createPizza(String[] pizzaInput) {
        String pizzaName = pizzaInput[1];
        int numberOfTopping = Integer.parseInt(pizzaInput[2]);
        return new Pizza(pizzaName, numberOfTopping);
    }
}
