package magicGame.models.magics;

public  abstract class MagicImpl implements Magic{
    private String name;
    private int bulletsCount;

    protected MagicImpl(String name, int bulletsCount) {
        this.name = name;
        this.bulletsCount = bulletsCount;
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public int getBulletsCount() {
        return 0;
    }

    @Override
    public int fire() {
        return 0;
    }
}
