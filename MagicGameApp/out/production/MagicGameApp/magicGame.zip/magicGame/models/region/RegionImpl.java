package magicGame.models.region;

import magicGame.models.magicians.Magician;

import java.util.Collection;

public class RegionImpl implements Region{
    private Collection data;
    @Override
    public String start(Collection<Magician> magicians) {
        return null;
    }
}
