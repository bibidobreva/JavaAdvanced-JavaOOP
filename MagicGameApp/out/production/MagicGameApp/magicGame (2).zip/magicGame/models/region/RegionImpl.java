package magicGame.models.region;

import magicGame.models.magicians.Magician;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class RegionImpl implements Region{
    private List<Magician> data;

    public RegionImpl() {
        this.data = new ArrayList<>();
    }

    @Override
    public String start(Collection<Magician> magicians) {
        //TODO
        return null;
    }
}
