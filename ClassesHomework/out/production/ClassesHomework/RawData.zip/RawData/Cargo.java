package RawData;

public class Cargo {
    private String cargoType;
    private int cargoWeight;

    public Cargo(String cargoType, int cargoWeight){
        this.cargoType = cargoType;
        this.cargoWeight = cargoWeight;
    }

}
