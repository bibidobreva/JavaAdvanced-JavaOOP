package CompanyRoster;

import java.sql.DataTruncation;

public class Employee implements Comparable {

    private String name;
    private double salary;
    private String position;
    private String department;
    private String email = "n/a";
    private int age = -1;

    public Employee(String name, double salary, String position, String department) {
        this.name = name;
        this.salary = salary;
        this.position = position;
        this.department = department;

    }

    public Employee(String name, double salary, String position, String department, String email) {
        this.name = name;
        this.salary = salary;
        this.position = position;
        this.department = department;
        this.email = email;
    }

    public Employee(String name, double salary, String position, String department, int age) {
        this.name = name;
        this.salary = salary;
        this.position = position;
        this.department = department;
        this.age = age;
    }

    public Employee(String name, double salary, String position, String department, String email, int age) {
        this.name = name;
        this.salary = salary;
        this.position = position;
        this.department = department;
        this.email = email;
        this.age = age;
    }

    public Employee() {

    }

    public String getDepartment() {
        return department;
    }

    public double getSalary() {
        return this.salary;
    }

    public int compareTo(Object compareTo) {
        Employee compareToEmp = (Employee)compareTo;
        if(salary==compareToEmp.salary) return 1;
        else if (salary<((Employee) compareTo).salary)return 1 ;
        else return -1;


    }

    @Override
    public String toString() {
        return String.format("%s %.2f %s %d", this.name, this.salary, this.email, this.age);
    }
}
