package ListyIterator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class ListyIterator {
    private List<String> elements;
    private int counter;

    public List<String> getString() {
        return elements;
    }

    public ListyIterator(String... elements) {
        this.elements = new ArrayList<>(Arrays.asList(elements));
        this.counter = 0;
    }

    public boolean Move() {
        if (hasNext()) {
            this.counter++;
            return true;
        }
        return false;
    }

    public boolean hasNext() {
        if (this.counter<this.elements.size()-1) {
            return true;
        } else {
            return false;
        }
    }

    public void Print(){
        if(this.elements.isEmpty()){
            throw new IllegalStateException("Invalid Operation!");
        }
        System.out.println(this.elements.get(counter));
    }


}
