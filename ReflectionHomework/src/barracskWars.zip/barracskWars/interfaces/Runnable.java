package barracskWars.interfaces;

public interface Runnable {
	void run();
}
