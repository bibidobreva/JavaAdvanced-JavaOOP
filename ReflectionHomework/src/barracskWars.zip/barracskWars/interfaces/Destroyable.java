package barracskWars.interfaces;

public interface Destroyable {
    
    int getHealth();
    
    void setHealth(int health);
}
