package barracskWars.interfaces;

public interface Executable {

	String execute();

}
