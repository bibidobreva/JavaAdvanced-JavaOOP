package barracskWars.interfaces;

public interface Attacker {
    
    int getAttackDamage();
}
